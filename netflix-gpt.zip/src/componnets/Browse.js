import React from 'react'

const Browse = () => {
  return (
    <div>
      browses
    </div>
  )
}

export default Browse
