import React from 'react'

const Body = () => {
  return (
    <div>
      Suganya Anbazhagan
    </div>
  )
}

export default Body
